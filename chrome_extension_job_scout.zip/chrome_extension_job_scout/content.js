// content.js
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "GET_JOB_INFO") {
    
    const currentUrl = window.location.href;
    // 判断是否为 view 页面
    const isViewUrl = currentUrl.includes("/view/") || currentUrl.includes("/jobs/view/");

    console.log(`Job Scout Triggered. URL: ${currentUrl}`);
    console.log(`Mode: ${isViewUrl ? "High Precision (View Page)" : "General Compatibility (Other)"}`);

    // ============================================================
    // 分支 1: 针对 /jobs/view/ 或 /view/ 的逻辑 (保持不变)
    // ============================================================
    if (isViewUrl) {
      (function runViewLogic() {
        // --- 基础工具函数 ---
        const cleanText = (text) => text ? text.replace(/[\n\r]+/g, ' ').replace(/\s+/g, ' ').trim() : "";

        const isStandalonePage = currentUrl.includes("/view/") || currentUrl.includes("/jobs/view/");

        // --- 策略 A: 列表页抓取 ---
        const scrapeListPage = () => {
            console.log("🛠️ Strategy: List Page (SPA)");
            
            const btn = document.querySelector('.jobs-description__footer-button') || 
                        document.querySelector('.show-more-less-html__button');
            if(btn) btn.click();

            return {
                title: cleanText(document.querySelector('.job-details-jobs-unified-top-card__job-title')?.innerText) || 
                       cleanText(document.querySelector('.jobs-unified-top-card__job-title')?.innerText),
                
                company: cleanText(document.querySelector('.job-details-jobs-unified-top-card__company-name a')?.innerText) || 
                         cleanText(document.querySelector('.jobs-unified-top-card__company-name')?.innerText),
                
                location: cleanText(document.querySelector('.job-details-jobs-unified-top-card__bullet')?.innerText) || 
                          cleanText(document.querySelector('.jobs-unified-top-card__bullet')?.innerText),
                
                description: cleanText(document.getElementById('job-details')?.innerText) || 
                             cleanText(document.querySelector('.jobs-description__content')?.innerText),
                
                url: window.location.href.split('?')[0],
                status: "applied"
            };
        };

        // --- 策略 B: 独立页抓取 (Meta/Title 分析) ---
        const scrapeStandalonePage = () => {
            console.log("🛠️ Strategy: Standalone Page (Meta/Title Analysis)");

            let metaTitle = document.title;
            metaTitle = metaTitle.replace(/^\(\d+\)\s*/, ""); 
            metaTitle = metaTitle.split(" | LinkedIn")[0]; 

            let derivedTitle = "";
            let derivedCompany = "";

            if (metaTitle.includes(" at ")) {
                const parts = metaTitle.split(" at ");
                derivedCompany = parts.pop();
                derivedTitle = parts.join(" at ");
            } else if (metaTitle.includes(" | ")) {
                 const parts = metaTitle.split(" | ");
                 if (parts.length >= 2) {
                     derivedCompany = parts[1];
                     derivedTitle = parts[0];
                 }
            }

            const ogTitle = document.querySelector('meta[property="og:title"]')?.content;
            if (ogTitle && !derivedTitle) derivedTitle = ogTitle;

            const h1 = document.querySelector('h1')?.innerText;
            const finalTitle = cleanText(derivedTitle || h1 || "Unknown Title");

            if (!derivedCompany) {
                const companyLink = document.querySelector('a[href*="/company/"]');
                if (companyLink) derivedCompany = companyLink.innerText;
                
                if (!derivedCompany) {
                    const logoImg = document.querySelector('.jobs-unified-top-card__company-logo') || 
                                    document.querySelector('img[alt*=" logo"]');
                    if (logoImg) derivedCompany = logoImg.getAttribute('alt').replace(' logo', '');
                }
            }
            const finalCompany = cleanText(derivedCompany || "Unknown Company");

            let finalLocation = "Remote / Unknown";
            const topCardText = document.querySelector('.top-card-layout') || document.body;
            if (topCardText) {
                const locationElement = document.querySelector('.topcard__flavor--bullet') || 
                                        document.querySelector('.job-details-jobs-unified-top-card__bullet');
                
                if (locationElement) {
                    finalLocation = locationElement.innerText;
                } else {
                    const allSpans = Array.from(document.querySelectorAll('span, div'))
                        .filter(el => el.innerText.length > 2 && el.innerText.length < 50);
                    const potentialLoc = allSpans.find(el => el.innerText.includes(','));
                    if (potentialLoc) finalLocation = potentialLoc.innerText;
                }
            }

            let description = "No description found";
            try {
                const showMoreBtn = Array.from(document.querySelectorAll('button'))
                    .find(b => b.innerText.includes('Show more') || b.innerText.includes('显示全部'));
                if (showMoreBtn) showMoreBtn.click();
            } catch(e){}

            const headings = Array.from(document.querySelectorAll('h2, h3, h4, strong, span'));
            const descHeader = headings.find(el => /About the job|Description|职位描述|Job summary/i.test(el.innerText));
            
            if (descHeader) {
                let container = descHeader.parentElement;
                for(let i=0; i<4; i++) {
                    if(container && container.innerText.length > 150) {
                        description = container.innerText;
                        break;
                    }
                    if(container) container = container.parentElement;
                }
            } else {
                const descEl = document.querySelector('.description__text') || 
                               document.querySelector('.core-section-container__content');
                if (descEl) description = descEl.innerText;
            }

            return {
                title: finalTitle,
                company: finalCompany,
                location: cleanText(finalLocation),
                description: cleanText(description).substring(0, 5000),
                url: window.location.href.split('?')[0],
                status: "applied"
            };
        };

        // --- 执行逻辑 A ---
        let jobData = {};
        try {
            if (isStandalonePage) {
                jobData = scrapeStandalonePage();
            } else {
                jobData = scrapeListPage();
                if (!jobData.title || jobData.title === "Unknown Title") {
                     console.log("List strategy failed, falling back to Meta analysis...");
                     jobData = scrapeStandalonePage();
                }
            }
        } catch (err) {
            console.error("Scraping error:", err);
            jobData = {
                title: "Error capturing title", 
                company: "Unknown", 
                url: window.location.href, 
                description: "Error: " + err.message
            };
        }

        if (jobData.description) {
            jobData.description = jobData.description.replace(/"/g, '""');
        }

        console.log("Job Scout Final Data (View Mode):", jobData);
        sendResponse(jobData);
      })();
    } 
    
    // ============================================================
    // 分支 2: 针对其他地址的通用逻辑 (已修正 Location 处理)
    // ============================================================
    else {
      (function runGeneralLogic() {
        
        // 辅助函数：按顺序尝试选择器列表
        const getField = (selectors) => {
          for (const s of selectors) {
            const el = document.querySelector(s);
            if (el && el.innerText && el.innerText.trim().length > 0) {
              return el.innerText.trim()
                .replace(/\n+/g, ' ') 
                .replace(/\s+/g, ' '); 
            }
          }
          return null;
        };

        // 辅助函数：根据文本定位描述
        const getDescriptionByText = () => {
          const headings = Array.from(document.querySelectorAll('h2, h3, h4, strong'));
          const target = headings.find(el => 
            /About the job|Description|职位描述|Job summary/i.test(el.innerText)
          );
          
          if (target) {
            const container = target.closest('.jobs-description') || 
                              target.closest('.jobs-box__html-content') ||
                              target.parentElement;
            if (container) return container.innerText;
          }
          return null;
        };

        // 1. 专门处理 Location 的逻辑
        let rawLocation = getField([
          '.job-details-jobs-unified-top-card__bullet',
          '.jobs-unified-top-card__bullet',
          '.top-card-layout__first-sub-line .topcard__flavor--bullet',
          '.topcard__flavor--bullet',
          '.job-details-jobs-unified-top-card__primary-description-container'
        ]);

        let cleanLocation = "Remote / Unknown";
        if (rawLocation) {
             // 【核心修改】在此处进行分割
             // 针对 "City, Country · Reposted 5 days ago · 100 applicants"
             // split('·') 会把它切成数组，我们取第一个元素 [0]
             cleanLocation = rawLocation.split('·')[0].trim();
        }

        // --- 执行逻辑 B ---
        const jobData = {
          title: getField([
            '.job-details-jobs-unified-top-card__job-title',
            '.jobs-unified-top-card__job-title',
            'h1.top-card-layout__title',
            '.topcard__title',
            'h1'
          ]) || "Unknown Title",

          company: getField([
            '.job-details-jobs-unified-top-card__company-name a',
            '.job-details-jobs-unified-top-card__company-name',
            '.top-card-layout__card .topcard__org-name-link',
            '.topcard__org-name-link',
            '.jobs-unified-top-card__company-name'
          ]) || "Unknown Company",

          // 使用上面处理过的干净地址
          location: cleanLocation,

          description: (
            document.getElementById('job-details') || 
            document.querySelector('.jobs-description__content') || 
            document.querySelector('.jobs-box__html-content') || 
            document.querySelector('.show-more-less-html__markup') ||
            { innerText: getDescriptionByText() }
          )?.innerText
            ?.replace(/\n+/g, ' ') 
            .replace(/"/g, '""') 
            .trim().substring(0, 5000) 
            || "No description found",

          url: window.location.href.split('?')[0], 
          status: "applied"
        };

        console.log("Job Scout Final Data (General Mode):", jobData);
        sendResponse(jobData);
      })();
    }
  }
  return true; 
});