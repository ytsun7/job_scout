// popup.js
const SUPABASE_URL = "https://ucabuiwtvhpyqehaytxj.supabase.co";
const SUPABASE_KEY = "sb_publishable_qRsPp469HJzOmpTc-KM-QQ_dNGZoKRj";

const authSection = document.getElementById('authSection');
const mainSection = document.getElementById('mainSection');
const statusEl = document.getElementById('status');

// 页面加载时检查登录态及 3 小时有效期
chrome.storage.local.get(['session', 'expiry'], (result) => {
    if (result.session && result.expiry) {
        // 检查当前时间是否小于过期时间
        if (Date.now() < result.expiry) {
            showMain(result.session);
        } else {
            // 已过期，清除存储
            chrome.storage.local.remove(['session', 'expiry']);
            statusEl.innerText = "Session expired. Please login.";
        }
    }
});

// 登录逻辑
document.getElementById('loginBtn').addEventListener('click', async () => {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    statusEl.innerText = "Logging in...";

    try {
        const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
            method: 'POST',
            headers: {
                'apikey': SUPABASE_KEY,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, password })
        });

        const data = await res.json();
        if (res.ok) {
            // 设置 3 小时过期时间 (当前时间 + 3 * 60 * 60 * 1000 毫秒)
            const expiryTime = Date.now() + (3 * 60 * 60 * 1000);
            chrome.storage.local.set({ session: data, expiry: expiryTime }, () => {
                showMain(data);
                statusEl.innerText = "Login successful!";
            });
        } else {
            statusEl.innerText = "Error: " + (data.error_description || "Check credentials");
        }
    } catch (err) {
        statusEl.innerText = "Connection failed.";
    }
});

// 抓取并上传逻辑
document.getElementById('collectBtn').addEventListener('click', async () => {
    statusEl.innerText = "Capturing...";

    chrome.storage.local.get(['session', 'expiry'], async (result) => {
        // 双重检查：是否存在且未过期
        if (!result.session || Date.now() > result.expiry) {
            statusEl.innerText = "Session expired. Please login again.";
            authSection.classList.remove('hidden');
            mainSection.classList.add('hidden');
            return;
        }

        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab.url.includes("linkedin.com")) {
            statusEl.innerText = "Please use on LinkedIn Job page.";
            return;
        }

        chrome.tabs.sendMessage(tab.id, { action: "GET_JOB_INFO" }, async (jobData) => {
            if (!jobData) {
                statusEl.innerText = "Error: Please refresh LinkedIn.";
                return;
            }

            try {
                const res = await fetch(`${SUPABASE_URL}/rest/v1/job_applications`, {
                    method: 'POST',
                    headers: {
                        'apikey': SUPABASE_KEY,
                        'Authorization': `Bearer ${result.session.access_token}`,
                        'Content-Type': 'application/json',
                        'Prefer': 'return=minimal'
                    },
                    body: JSON.stringify({
                        ...jobData,
                        user_id: result.session.user.id
                    })
                });

                if (res.ok) {
                    statusEl.innerText = "✅ Saved to Cloud!";
                } else {
                    statusEl.innerText = "❌ Sync Error (Check RLS)";
                }
            } catch (err) {
                statusEl.innerText = "❌ Network error.";
            }
        });
    });
});

function showMain(session) {
    authSection.classList.add('hidden');
    mainSection.classList.remove('hidden');
    document.getElementById('userEmail').innerText = "User: " + session.user.email;
}

document.getElementById('logoutBtn').addEventListener('click', () => {
    chrome.storage.local.remove(['session', 'expiry'], () => {
        authSection.classList.remove('hidden');
        mainSection.classList.add('hidden');
        statusEl.innerText = "Logged out.";
    });
});

// 新增：点击链接跳转网页
document.getElementById('openDashboard').addEventListener('click', () => {
    chrome.tabs.create({ url: "https://myjobscout.streamlit.app" });
});